export const generateLovePercent = () => {
    return `${~~(Math.random() * 100)} %`;
};